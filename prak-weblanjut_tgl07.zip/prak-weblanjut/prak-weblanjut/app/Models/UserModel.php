<?php

namespace App\Models;

use Codeigniter\Model;

class UserModel extends Model
{
    protected $table = 'user';
    protected $primaryKey = 'id';
    protected $allowedFields = ['fullname', 'email', 'password'];
}
